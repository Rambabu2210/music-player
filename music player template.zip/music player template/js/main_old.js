var myapp = angular.module("my_music",[]);

/*---logo controller----*/
myapp.controller("logo_ctrl",function($scope){	
	$scope.logo=[{url:"logo.png"}];	
	/* console.log($scope.about); */
}
);

/*----Menu Controller---*/
myapp.controller("menu_ctrl",function($scope)
{
	$scope.menu=[
	{name:"HOME",url:"/home.html"},
	{name:"ABOUT",url:"/about.html"},
	{name:"SERVICE",url:"/service.html"},
	{name:"DOWNLOAD",url:"/download.html"},
	{name:"CONTACT",url:"/contact.html"},
	{name:"HELP",url:"/help.html"}];	
});
/*----Album details----*/
myapp.controller("album_ctrl",function($scope){
	
	$scope.album=[
	{cover:"1.jpg",name:"Billa",year:"2016",play:"1",download:"comming",des:"Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus."},
	{cover:"2.jpg",name:"Puli",year:"2015",play:"2",download:"download",des:"Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus."},
	{cover:"3.jpg",name:"144",year:"2011",play:"3",download:"comming",des:"Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus."},
	{cover:"4.jpg",name:"IRU mugan",year:"2012",play:"4",download:"download",des:"Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus."},
	{cover:"5.jpg",name:"mayakam enna",year:"2014",play:"5",download:"download",des:"Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus."},
	{cover:"6.jpg",name:"ra-one",year:"2016",play:"6",download:"download",des:"Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus."},
	{cover:"7.jpg",name:"dhoom",year:"2015",play:"7",download:"comming",des:"Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus."},
	{cover:"8.jpg",name:"AYM",year:"2014",play:"8",download:"download",des:"Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus."},
	{cover:"9.jpg",name:"ATM",year:"2013",play:"9",download:"download",des:"Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus."}
	];
	
});





