$(document).ready(function(){
/*----Page Loading ---*/
jQuery(window).load(function() {
   jQuery('.load_music').addClass('complete');
});
/*--------- player stop and play ------------*/
$('.play').click(function()
{
	$(this).toggleClass("stop");
  
});
$('.play').click(function()
{
	$('body').find('.eq').toggleClass("eq_stop");
});
$('.play_close').click(function()
{
	$('body').find('#player').toggleClass("close_palyer");
});
/*----library Open---*/
$('.open_library').click(function()
{
	$('body').find('.lib_area').toggleClass('open_lib');
});
$('.lib_close').click(function()
{
	$('body').find('.lib_area').toggleClass('open_lib');
});
/*----popup overlay add ---*/
 $('.md-trigger').click(function()
{
	$('body').find('.modal_lay').addClass("body_overlay");
});

$('.md-close').click(function()
{
	$('body').find('.modal_lay').removeClass("body_overlay");
});

 $('.md-min').click(function()
{
	$('body').find('.modal_lay').removeClass("body_overlay");
});
$('.md-max').click(function()
{
	$('body').find('.modal_lay').addClass("body_overlay");
}); 
/*----popup minimize and maximize ---*/
 $('.md-min').click(function()
{
$('body').find('.md-modal').addClass('minimize');
});

$('.md-max').click(function()
{
$('body').find('.md-modal').removeClass('minimize');
});
 
/*----NAV menu ---*/
$('.sub_nav').click(function()
{
$(this).find('ul').toggleClass('sub_open');
$(this).toggleClass('menu_expand');
});
$('.menu_icon').click(function()
{
$(this).toggleClass('menu_icon_open');
$('body').find('nav').toggleClass('menu_open');
});
/*-------Flxed Layout-------*/
  function setHeight() {
    total = $(window).outerHeight();
    fixed = total - 101;
	/* console.log(fixed); */
    $('body').css('height', total);
    $('.inner_lay').css('height', fixed);
    $('#right_side').css('height', fixed);
    $('#page_cont_side').css('height', fixed);
  };
  setHeight();
  
  $(window).resize(function() {
    setHeight();
  });


/*----sticky header ---*/
 /* jQuery(window).scroll(function() { 
				var scroll = jQuery(window).scrollTop();
				if (scroll >= 100) {
					jQuery(".header_lay").addClass("sticky");
				}
				else
				{
					jQuery(".header_lay").removeClass("sticky");
				}
				});   */

/*-----Modal_open-----*/
$('.md-trigger').click(function()
{
$(this).next(".md-modal").addClass('md-show');
});
$('.md-close').click(function()
{
$('body').find(".md-modal").removeClass('md-show');
});
/*----AddtoplayList----*/
$('.add_play_list').click(function()
{
 $('body').find('.lib_area').addClass("open_lib"); 
});

/* $('.md-trigger').click(function()
{
	$('body').find('.container_lay').addClass("back_disable");
});

$('.md-close').click(function()
{
	$('body').find('.container_lay').removeClass("back_disable");
});

$('.md-min').click(function()
{
	$('body').find('.container_lay').removeClass("back_disable");
});

$('.md-max').click(function()
{
	$('body').find('.container_lay').addClass("back_disable");
}); */
});

/*-----Song open----*/
function opensong(a)
{
	/* $(a).parent('li').addClass('list_song_open'); */
	
	
};