(function(){

  var t = {
    playlist: [
      {
        file: "media/tracks/01.mp3",
        thumb: "media/thumbs/01.jpg",
        trackName: "Dusk",
        trackArtist: "Tobu & Syndec",
        trackAlbum: "Single",
      },
      {
        file: "media/tracks/02.mp3",
        thumb: "media/thumbs/02.jpg",
        trackName: "Blank",
        trackArtist: "Disfigure",
        trackAlbum: "Single",
      },
      {
        file: "media/tracks/03.mp3",
        thumb: "media/thumbs/03.jpg",
        trackName: "Fade",
        trackArtist: "Alan Walker",
        trackAlbum: "Single",
      }
    ]
  }

  $(".jAudio").jAudio(t);

})();