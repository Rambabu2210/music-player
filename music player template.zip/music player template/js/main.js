var myapp = angular.module("my_music",[]);

/*---logo controller----*/
myapp.controller("logo_ctrl",function($scope){	
	$scope.logo=[{url:"logo.png"}];	
	/* console.log($scope.about); */
}
);

/*----Menu Controller---*/
myapp.controller("menu_ctrl",function($scope)
{
	$scope.menu=[
	{name:"menu-1",url:"index.html"},
	{name:"menu-2",url:"index.html"},
	{name:"menu-3",url:"index.html"},
	{name:"menu-4",url:"index.html"},
	{name:"menu-5",url:"index.html"},
	{name:"menu-6",url:"index.html"}];	
});
/*----Album details----*/
myapp.controller("album_ctr",function($scope){
	
	$scope.album=[
	{
		cover:"1.jpg",
		name:"Movie1",
		year:"2016",
		play:"1",
		download:"comming",
		des:"Vestibulum ac diam sit amet quam....",
		songs:[
		{
			song:"ThemeSong"
		},
		{
			song:"ThemeSong1"
		}
		]
		},
		{
		cover:"2.jpg",
		name:"Movie2",
		year:"2016",
		play:"1",
		download:"comming",
		des:"Vestibulum ac diam sit amet quam....",
		songs:[
		{
			song:"ThemeSong"
		},
		{
			song:"ThemeSong1"
		}
		]
		},
		{
		cover:"3.jpg",
		name:"Movie3",
		year:"2016",
		play:"1",
		download:"comming",
		des:"Vestibulum ac diam sit amet quam....",
		songs:[
		{
			song:"ThemeSong"
		},
		{
			song:"ThemeSong1"
		}
		]
		},
		{
		cover:"4.jpg",
		name:"Movie4",
		year:"2016",
		play:"1",
		download:"comming",
		des:"Vestibulum ac diam sit amet quam....",
		songs:[
		{
			song:"ThemeSong"
		},
		{
			song:"ThemeSong1"
		}
		]
		},
		{
		cover:"5.jpg",
		name:"Movie5",
		year:"2016",
		play:"1",
		download:"comming",
		des:"Vestibulum ac diam sit amet quam....",
		songs:[
		{
			song:"ThemeSong"
		},
		{
			song:"ThemeSong1"
		}
		]
		},
		{
		cover:"6.jpg",
		name:"Movie6",
		year:"2016",
		play:"1",
		download:"comming",
		des:"Vestibulum ac diam sit amet quam....",
		songs:[
		{
			song:"ThemeSong"
		},
		{
			song:"ThemeSong1"
		}
		]
		},
		{
		cover:"7.jpg",
		name:"Movie7",
		year:"2016",
		play:"1",
		download:"comming",
		des:"Vestibulum ac diam sit amet quam....",
		songs:[
		{
			song:"ThemeSong"
		},
		{
			song:"ThemeSong1"
		}
		]
		},
		{
		cover:"8.jpg",
		name:"Movie8",
		year:"2016",
		play:"1",
		download:"comming",
		des:"Vestibulum ac diam sit amet quam....",
		songs:[
		{
			song:"ThemeSongsfsdffsd"
		},
		{
			song:"ThemeSong1"
		}
		]
		},
		
	];
	
	$scope.play_list=[];
	$scope.playSong = function(albumIndex)
	{
		$scope.play_list.push($scope.album[albumIndex]); 
		$scope.play_list[albumIndex].disable=true; 
		
	};
	$scope.remove_movie = function(removeIndex)
	{
		$scope.play_list.splice(removeIndex,1); 
		$scope.play_list[removeIndex].disable=false;
		
	};
	
});





